import { n as __toESM } from "../_runtime.mjs";
import { _ as require_jsx_runtime, a as Trigger2, i as Root2, n as Header, r as Item, t as Content2, v as require_react } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { M as ChevronDown } from "../_libs/lucide-react.mjs";
import { s as cn } from "./request-access-modal-YqegOqKY.mjs";
import { n as SiteLayout } from "./site-layout-OToWjpKs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/faq-ByCgVSSq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Accordion = Root2;
var AccordionItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item, {
	ref,
	className: cn("border-b", className),
	...props
}));
AccordionItem.displayName = "AccordionItem";
var AccordionTrigger = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
	className: "flex",
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Trigger2, {
		ref,
		className: cn("flex flex-1 items-center justify-between py-4 text-sm font-medium cursor-pointer transition-all hover:underline text-left [&[data-state=open]>svg]:rotate-180", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200" })]
	})
}));
AccordionTrigger.displayName = Trigger2.displayName;
var AccordionContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	className: "overflow-hidden text-sm data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down",
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("pb-4 pt-0", className),
		children
	})
}));
AccordionContent.displayName = Content2.displayName;
var faqItems = [
	{
		q: "Is Dverif open for signup?",
		a: "No — Dverif is invite-only. Request access and our team will reach out."
	},
	{
		q: "How fast is a typical verification?",
		a: "Most verifications complete in minutes when the issuer is on Dverif."
	},
	{
		q: "Do you support bulk requests?",
		a: "Yes, teams on paid plans can send and track requests in bulk with a full audit trail."
	},
	{
		q: "How do you prevent fraud?",
		a: "We verify directly with issuers and flag tampering, duplicates and mismatches automatically."
	}
];
function FaqSection({ as = "h2" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "page-hero-grid section-y",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-4 sm:px-6 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-2xl mx-auto text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "section-kicker",
					children: "FAQ"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(as, {
					className: "mt-2 text-3xl sm:text-4xl font-bold tracking-tight",
					children: "Questions, answered."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "surface-card mt-10 rounded-2xl px-5 py-2 sm:px-7 sm:py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Accordion, {
					type: "single",
					collapsible: true,
					className: "w-full divide-y divide-border",
					children: faqItems.map((it, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AccordionItem, {
						value: `i-${i}`,
						className: "border-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionTrigger, {
							className: "py-5 text-left text-base font-semibold hover:no-underline",
							children: it.q
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccordionContent, {
							className: "pb-5 text-sm leading-6 text-muted-foreground",
							children: it.a
						})]
					}, i))
				})
			})]
		})
	});
}
function FaqPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqSection, { as: "h1" }) });
}
//#endregion
export { FaqPage as component };
