import { n as __toESM } from "../_runtime.mjs";
import { _ as require_jsx_runtime, l as Slot, v as require_react } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { E as FileCheckCorner, N as Check, c as Sparkles, i as UserRound, j as CircleCheck, l as ShieldCheck, n as X, p as Phone, v as Mail, y as LoaderCircle } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay$1, c as DialogTrigger$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Root } from "../_libs/radix-ui__react-label.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/request-access-modal-YqegOqKY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ThemeCtx = (0, import_react.createContext)({
	theme: "light",
	toggle: () => {}
});
function ThemeProvider({ children }) {
	const [theme, setTheme] = (0, import_react.useState)("light");
	(0, import_react.useEffect)(() => {
		const stored = typeof localStorage !== "undefined" && localStorage.getItem("dverif-theme");
		if (stored === "dark" || stored === "light") setTheme(stored);
	}, []);
	(0, import_react.useEffect)(() => {
		const root = document.documentElement;
		if (theme === "dark") root.classList.add("dark");
		else root.classList.remove("dark");
		try {
			localStorage.setItem("dverif-theme", theme);
		} catch {}
	}, [theme]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeCtx.Provider, {
		value: {
			theme,
			toggle: () => setTheme((t) => t === "dark" ? "light" : "dark")
		},
		children
	});
}
var useTheme = () => (0, import_react.useContext)(ThemeCtx);
var BASE_URL = (typeof processModule !== "undefined" ? processModule.env.REACT_APP_API_BASE_URL : void 0) || "https://backend.dverif.com";
var getBaseUrl = () => {
	if (!BASE_URL) throw new Error("API URL is not configured. Please try again shortly.");
	return BASE_URL.replace(/\/$/, "");
};
async function submitContactForm(formData) {
	const baseUrl = getBaseUrl();
	try {
		const response = await fetch(`${baseUrl}/leads/contact`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(formData)
		});
		const data = await response.json().catch(() => ({}));
		if (!response.ok) throw new Error(data.message || "We couldn’t send your message. Please try again.");
		return data;
	} catch (error) {
		if (error instanceof TypeError) throw new Error("We’re having trouble connecting. Please check your connection and try again.");
		throw error;
	}
}
async function submitRequestAccess(formData) {
	const baseUrl = getBaseUrl();
	try {
		const response = await fetch(`${baseUrl}/leads/request-access`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(formData)
		});
		const data = await response.json().catch(() => ({}));
		if (!response.ok) throw new Error(data.message || "We couldn’t submit your access request. Please try again.");
		return data;
	} catch (error) {
		if (error instanceof TypeError) throw new Error("We’re having trouble connecting. Please check your connection and try again.");
		throw error;
	}
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var Dialog = Dialog$1;
var DialogTrigger = DialogTrigger$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-slate-950/45 backdrop-blur-sm data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
});
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var labelVariants = cva("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn(labelVariants(), className),
	...props
}));
Label.displayName = Root.displayName;
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
			destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
			outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
			secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
			ghost: "hover:bg-accent hover:text-accent-foreground",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-9 px-4 py-2",
			sm: "h-8 rounded-md px-3 text-xs",
			lg: "h-10 rounded-md px-8",
			icon: "h-9 w-9"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button$1 = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button$1.displayName = "Button";
function InputField({ label, icon: Icon, error, className, id, ...props }) {
	const fieldId = id || props.name;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: fieldId,
				className: "text-sm font-medium text-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "group relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground transition-colors group-focus-within:text-[#4F8CFF]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: fieldId,
					className: cn("h-12 rounded-xl border-border/80 bg-background/70 pl-10 shadow-sm transition-all placeholder:text-muted-foreground/70 focus-visible:border-[#4F8CFF] focus-visible:ring-4 focus-visible:ring-[#4F8CFF]/15", error && "border-destructive focus-visible:ring-destructive/15", className),
					...props
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-destructive",
				children: error
			})
		]
	});
}
function TextArea({ label, icon: Icon, error, className, id, ...props }) {
	const fieldId = id || props.name;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor: fieldId,
				className: "text-sm font-medium text-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "group relative",
				children: [Icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "pointer-events-none absolute left-3.5 top-3.5 h-4 w-4 text-muted-foreground transition-colors group-focus-within:text-[#4F8CFF]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: fieldId,
					className: cn("resize-none rounded-xl border-border/80 bg-background/70 py-3 shadow-sm transition-all placeholder:text-muted-foreground/70 focus-visible:border-[#4F8CFF] focus-visible:ring-4 focus-visible:ring-[#4F8CFF]/15", Icon && "pl-10", error && "border-destructive focus-visible:ring-destructive/15", className),
					...props
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium text-destructive",
				children: error
			})
		]
	});
}
function Button({ children, loading, className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button$1, {
		className: cn("btn-primary-glow h-12 rounded-xl px-6 font-semibold", className),
		disabled: loading || props.disabled,
		...props,
		children: [loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }), children]
	});
}
var benefits = [
	"Secure & Private",
	"Fast Onboarding",
	"Built for Teams"
];
function RequestAccessModal({ children, variant = "primary", triggerLabel = "Schedule A Meeting" }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const handleSubmit = async (event) => {
		event.preventDefault();
		const form = event.currentTarget;
		const formData = new FormData(form);
		setError(null);
		setLoading(true);
		try {
			await submitRequestAccess({
				organization_name: String(formData.get("organization_name") || "").trim(),
				contact_name: String(formData.get("contact_name") || "").trim(),
				email: String(formData.get("email") || "").trim(),
				phone: String(formData.get("phone") || "").trim(),
				company_size: String(formData.get("company_size") || "").trim(),
				message: String(formData.get("message") || "").trim()
			});
			form.reset();
			setDone(true);
		} catch (submissionError) {
			setError(submissionError instanceof Error ? submissionError.message : "We couldn’t send your request. Please try again.");
		} finally {
			setLoading(false);
		}
	};
	const changeOpen = (isOpen) => {
		setOpen(isOpen);
		if (!isOpen) window.setTimeout(() => {
			setDone(false);
			setError(null);
		}, 200);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: changeOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: children ?? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: variant === "outline" ? "outline" : "default",
				className: variant === "outline" ? "border-border bg-background text-foreground shadow-none hover:bg-accent" : "",
				children: triggerLabel
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			className: "max-h-[92vh] max-w-[min(94vw,900px)] overflow-y-auto rounded-2xl border-white/40 bg-background/95 p-0 shadow-2xl backdrop-blur-xl sm:rounded-2xl",
			children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-6 py-16 text-center sm:px-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-[#4F8CFF]/10 text-[#4F8CFF]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-8 w-8" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-6 text-2xl font-bold tracking-tight",
						children: "Your request is on its way"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-3 max-w-md text-sm leading-6 text-muted-foreground",
						children: "Thanks for your interest in Dverif. Our team will review your details and be in touch shortly."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						onClick: () => changeOpen(false),
						className: "mt-7",
						children: "Close"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-[.86fr_1.14fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "relative overflow-hidden bg-[linear-gradient(135deg,#4F8CFF,#6C63FF)] px-6 py-10 text-white sm:px-10 lg:py-12",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -left-16 top-0 h-48 w-48 rounded-full bg-white/10 blur-2xl" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -bottom-20 right-0 h-56 w-56 rounded-full bg-[#8dd7ff]/20 blur-3xl" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative mb-8 grid h-20 w-20 place-items-center rounded-2xl border border-white/25 bg-white/15 shadow-lg backdrop-blur-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheckCorner, { className: "h-9 w-9" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "absolute -bottom-2 -right-2 h-8 w-8 rounded-full bg-white p-1.5 text-[#5a75ff]" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold uppercase tracking-[0.18em] text-white/75",
									children: "Dverif access"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 text-3xl font-bold tracking-tight",
									children: "Request Access"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 max-w-xs text-sm leading-6 text-white/80",
									children: "Join teams that make document verification clearer, safer, and easier to manage."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-8 space-y-4",
									children: benefits.map((benefit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex items-center gap-3 text-sm font-medium",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid h-6 w-6 place-items-center rounded-full bg-white/15",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" })
										}), benefit]
									}, benefit))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-10 flex items-center gap-2 text-xs text-white/70",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-4 w-4" }), " Usually responds within one business day"]
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "px-6 py-10 sm:px-10 lg:py-12",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
						className: "pr-8 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
							className: "text-2xl font-bold",
							children: "Tell us a little about you"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
							className: "mt-2 leading-6",
							children: "We’ll use this to make your onboarding relevant from day one."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: handleSubmit,
						className: "mt-7 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputField, {
								id: "ra-name",
								name: "name",
								label: "Name",
								icon: UserRound,
								required: true,
								placeholder: "Jane Doe",
								autoComplete: "name"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputField, {
								id: "ra-email",
								name: "email",
								label: "Work Email",
								icon: Mail,
								type: "email",
								required: true,
								placeholder: "jane@company.com",
								autoComplete: "email"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputField, {
								id: "ra-phone",
								name: "phone",
								label: "Phone",
								icon: Phone,
								type: "tel",
								required: true,
								placeholder: "+1 (555) 000-0000",
								autoComplete: "tel"
							}),
							error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "alert",
								className: "rounded-lg bg-destructive/10 px-3 py-2.5 text-sm text-destructive",
								children: error
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								loading,
								className: "mt-2 w-full",
								children: loading ? "Sending request…" : "Schedule A Meeting"
							})
						]
					})]
				})]
			})
		})]
	});
}
//#endregion
export { TextArea as a, submitContactForm as c, RequestAccessModal as i, useTheme as l, Button$1 as n, ThemeProvider as o, InputField as r, cn as s, Button as t };
