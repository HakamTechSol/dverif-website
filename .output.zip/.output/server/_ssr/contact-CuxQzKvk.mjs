import { n as __toESM } from "../_runtime.mjs";
import { _ as require_jsx_runtime, v as require_react } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { A as Clock3, I as Building2, d as Send, g as MessageCircle, h as MessageSquareText, i as UserRound, j as CircleCheck, p as Phone, v as Mail } from "../_libs/lucide-react.mjs";
import { a as TextArea, c as submitContactForm, r as InputField, t as Button } from "./request-access-modal-YqegOqKY.mjs";
import { n as SiteLayout } from "./site-layout-OToWjpKs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-CuxQzKvk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var contactCards = [
	{
		icon: Mail,
		title: "Email us",
		copy: "For general questions and support.",
		value: "dverif26@gmail.com",
		href: "mailto:dverif26@gmail.com",
		tint: "bg-[#4F8CFF]/10 text-[#4F8CFF]"
	},
	{
		icon: MessageCircle,
		title: "WhatsApp",
		copy: "A quick chat with our team.",
		value: "Start a conversation",
		href: "https://wa.me/00000000000",
		tint: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
	},
	{
		icon: Clock3,
		title: "Business hours",
		copy: "Monday — Friday",
		value: "9:00 AM — 6:00 PM",
		tint: "bg-violet-500/10 text-violet-600 dark:text-violet-400"
	}
];
function Page() {
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [done, setDone] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const submit = async (event) => {
		event.preventDefault();
		const form = event.currentTarget;
		const data = new FormData(form);
		setError(null);
		setLoading(true);
		try {
			await submitContactForm({
				name: String(data.get("name") || "").trim(),
				email: String(data.get("email") || "").trim(),
				phone: String(data.get("phone") || "").trim(),
				subject: String(data.get("subject") || "").trim(),
				message: String(data.get("message") || "").trim()
			});
			form.reset();
			setDone(true);
		} catch (submissionError) {
			setError(submissionError instanceof Error ? submissionError.message : "We couldn’t send your message. Please try again.");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "page-hero-grid py-16 sm:py-20 lg:py-24",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-4 sm:px-6 lg:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mx-auto max-w-2xl text-center animate-fade-up",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-5 text-4xl font-bold tracking-[-.04em] sm:text-5xl",
					children: "How Can we Help?"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-base leading-7 text-muted-foreground sm:text-lg",
					children: "Have a question, need support, or want to explore Dverif? Send us a note and we’ll get back to you shortly."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 grid gap-6 lg:grid-cols-[1.16fr_.84fr] lg:gap-8 lg:items-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "surface-card relative overflow-hidden rounded-2xl p-6 sm:p-9",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-primary via-primary-glow to-primary" }), done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-h-[525px] flex-col items-center justify-center text-center animate-fade-up",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-16 w-16 place-items-center rounded-2xl bg-[#4F8CFF]/10 text-[#4F8CFF]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-8 w-8" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-6 text-2xl font-bold",
								children: "Message sent successfully"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 max-w-sm text-sm leading-6 text-muted-foreground",
								children: "Thanks for reaching out. A member of our team will reply as soon as possible."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: () => setDone(false),
								className: "mt-7",
								children: "Send another message"
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-[linear-gradient(135deg,#4F8CFF,#6C63FF)] text-white shadow-lg shadow-[#4F8CFF]/25",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-5 w-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-bold tracking-tight",
							children: "Contact Us"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "We’d love to hear what’s on your mind."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: submit,
						className: "mt-8 space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-5 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputField, {
									id: "contact-name",
									name: "name",
									label: "Name",
									icon: UserRound,
									required: true,
									placeholder: "Jane Doe",
									autoComplete: "name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputField, {
									id: "contact-email",
									name: "email",
									label: "Email",
									icon: Mail,
									type: "email",
									required: true,
									placeholder: "jane@company.com",
									autoComplete: "email"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-5 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputField, {
									id: "contact-phone",
									name: "phone",
									label: "Phone",
									icon: Phone,
									type: "tel",
									required: true,
									placeholder: "+1 (555) 000-0000",
									autoComplete: "tel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputField, {
									id: "contact-subject",
									name: "subject",
									label: "Subject",
									icon: Building2,
									required: true,
									placeholder: "How Can we Help?"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextArea, {
								id: "contact-message",
								name: "message",
								label: "Message",
								icon: MessageSquareText,
								required: true,
								rows: 5,
								placeholder: "Tell us a little more about what you need…"
							}),
							error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "alert",
								className: "rounded-xl bg-destructive/10 px-4 py-3 text-sm text-destructive",
								children: error
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								loading,
								className: "w-full sm:w-auto",
								children: loading ? "Sending message…" : "Send Message"
							})
						]
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "section-frame space-y-4 p-4 sm:p-5",
					children: [contactCards.map(({ icon: Icon, title, copy, value, href, tint }) => {
						const content = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `grid h-11 w-11 place-items-center rounded-xl ${tint}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-semibold",
									children: title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-0.5 text-sm text-muted-foreground",
									children: copy
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm font-semibold text-foreground",
									children: value
								})
							]
						})] });
						return href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href,
							target: href.startsWith("http") ? "_blank" : void 0,
							rel: href.startsWith("http") ? "noreferrer" : void 0,
							className: "surface-card card-hover flex gap-4 rounded-2xl p-5 sm:p-6",
							children: content
						}, title) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "surface-card flex gap-4 rounded-2xl p-5 sm:p-6",
							children: content
						}, title);
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative overflow-hidden rounded-2xl border border-[#4F8CFF]/20 bg-[linear-gradient(135deg,rgba(79,140,255,.12),rgba(108,99,255,.11))] p-6 sm:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-5 -top-6 h-20 w-20 rounded-full bg-white/35 blur-xl" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "relative text-lg font-bold",
								children: "We’re here to help"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "relative mt-2 text-sm leading-6 text-muted-foreground",
								children: "Whether you’re just getting started or need a hand with something specific, our team is ready to help."
							})
						]
					})]
				})]
			})]
		})
	}) });
}
//#endregion
export { Page as component };
