import { n as __toESM } from "../_runtime.mjs";
import { _ as require_jsx_runtime, v as require_react } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { E as FileCheckCorner, T as FileText, w as Inbox, x as LayoutDashboard } from "../_libs/lucide-react.mjs";
import { i as RequestAccessModal } from "./request-access-modal-YqegOqKY.mjs";
import { n as SiteLayout } from "./site-layout-OToWjpKs.mjs";
import { r as SectionHeader } from "./routes-DP2jsI5p.mjs";
import { t as ProductCapabilities } from "./product-capabilities-Cs1FSbPz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/features-BSC7lQ1r.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useInView(options) {
	const ref = (0, import_react.useRef)(null);
	const [inView, setInView] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const observer = new IntersectionObserver(([entry]) => {
			if (entry.isIntersecting) {
				setInView(true);
				observer.disconnect();
			}
		}, {
			threshold: .15,
			...options
		});
		observer.observe(el);
		return () => observer.disconnect();
	}, [options]);
	return {
		ref,
		inView
	};
}
var pageFeatureItems = [
	{
		icon: LayoutDashboard,
		title: "Secure Sign In",
		body: "A simple and secure starting point for your team.",
		images: [{
			src: "/assets/login.jpeg",
			alt: "Dverif login screen"
		}]
	},
	{
		icon: LayoutDashboard,
		title: "Team Management",
		body: "Keep your organization and team details in one place.",
		images: [{
			src: "/assets/teampage.jpeg",
			alt: "Dverif team management screen"
		}]
	},
	{
		icon: FileCheckCorner,
		title: "Verification Requests",
		body: "Create, manage and track verification requests with a clear workflow.",
		images: [{
			src: "/assets/verification-request.jpeg",
			alt: "Dverif verification request screen"
		}]
	},
	{
		icon: Inbox,
		title: "Inbox",
		body: "Keep requests and important updates organized in one inbox.",
		images: [{
			src: "/assets/inbox.jpeg",
			alt: "Dverif inbox screen"
		}]
	},
	{
		icon: FileText,
		title: "Document Review",
		body: "Review submitted documents with all the details you need.",
		images: [{
			src: "/assets/documentreviwe.jpeg",
			alt: "Dverif document review screen"
		}]
	},
	{
		icon: LayoutDashboard,
		title: "Multi-Admin Access",
		body: "Give the right people access to manage your organization.",
		images: [{
			src: "/assets/multiadmin.jpeg",
			alt: "Dverif multi-admin management screen"
		}]
	},
	{
		icon: FileCheckCorner,
		title: "Attendance Tracking",
		body: "Monitor attendance records from a clear, centralized view.",
		images: [{
			src: "/assets/attendence.jpeg",
			alt: "Dverif attendance tracking screen"
		}]
	},
	{
		icon: FileText,
		title: "Leave Requests",
		body: "Submit and manage employee leave requests with ease.",
		images: [{
			src: "/assets/leaverequest1.jpeg",
			alt: "Dverif leave request overview"
		}, {
			src: "/assets/leaverequest2.jpeg",
			alt: "Dverif leave request details"
		}]
	},
	{
		icon: LayoutDashboard,
		title: "Salary Management",
		body: "Access and manage salary information in one secure place.",
		images: [{
			src: "/assets/salarymanagment.jpeg",
			alt: "Dverif salary management screen"
		}]
	},
	{
		icon: Inbox,
		title: "Language Support",
		body: "Use the platform in the language that works best for your team.",
		images: [{
			src: "/assets/langugesupport.jpeg",
			alt: "Dverif language support screen"
		}]
	}
];
function ShotFrame({ images, title }) {
	const [active, setActive] = (0, import_react.useState)(0);
	const multi = images.length > 1;
	(0, import_react.useEffect)(() => {
		if (!multi) return;
		const id = window.setInterval(() => setActive((i) => (i + 1) % images.length), 2800);
		return () => window.clearInterval(id);
	}, [multi, images.length]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex aspect-video w-full items-center justify-center overflow-hidden rounded-xl border border-border bg-section p-3 shadow-inner",
		children: [images.map((img, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: img.src,
			alt: img.alt,
			loading: "lazy",
			decoding: "async",
			className: `absolute inset-3 m-auto h-[calc(100%-1.5rem)] w-[calc(100%-1.5rem)] object-contain object-center transition-opacity duration-700 ease-in-out ${multi ? active === i ? "opacity-100" : "opacity-0" : "opacity-100"}`
		}, img.src)), multi && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-x-0 bottom-2.5 flex justify-center gap-1.5",
			"aria-label": `${title} screenshots`,
			children: images.map((img, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-label": active === i ? `${img.alt}, active` : img.alt,
				className: `h-1.5 rounded-full transition-all duration-300 ${active === i ? "w-5 bg-primary" : "w-1.5 bg-muted-foreground/40"}`
			}, img.src))
		})]
	});
}
function FeatureCard({ item, index = 0 }) {
	const { ref, inView } = useInView({ threshold: .15 });
	const Icon = item.icon;
	const layout = [
		"lg:col-span-7",
		"lg:col-span-5",
		"lg:col-span-5",
		"lg:col-span-7"
	][index % 4];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref,
		className: `group relative flex h-full flex-col overflow-hidden rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-elegant)] transition-[transform,box-shadow,border-color] duration-300 hover:-translate-y-1.5 hover:border-primary/40 sm:p-7 ${layout} ${inView ? "reveal-in" : "reveal"}`,
		style: { animationDelay: `${index * .09}s` },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-0 h-1 origin-left scale-x-0 bg-gradient-to-r from-primary to-primary-glow transition-transform duration-300 group-hover:scale-x-100" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "w-full",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShotFrame, {
					images: item.images,
					title: item.title
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex min-w-0 items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary transition-transform duration-300 group-hover:scale-110",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "min-w-0 text-lg font-semibold tracking-tight sm:text-xl",
					children: item.title
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-muted-foreground",
				children: item.body
			})] })
		]
	});
}
function FeatureShowcase() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-14 grid auto-rows-[minmax(220px,auto)] gap-5 sm:gap-7 md:grid-cols-2 lg:grid-cols-12",
		children: pageFeatureItems.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeatureCard, {
			item,
			index: i
		}, item.title))
	});
}
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "enterprise-dark pb-16 pt-20 sm:pb-20 lg:pt-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-page animate-fade-up text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mx-auto mt-3 max-w-3xl text-4xl font-bold leading-[1.06] tracking-tight sm:text-5xl lg:text-[3.5rem]",
					children: "Build for Teams that Verify at Scale"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-5 max-w-2xl text-lg leading-relaxed text-slate-300",
					children: "Every capability in Dverif is designed to remove friction between issuers, verifiers and organizations."
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "section-band section-y pt-10 sm:pt-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container-page",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "section-frame p-5 sm:p-8 lg:p-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeatureShowcase, {})
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCapabilities, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "enterprise-dark section-y",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					title: "Ready to See it in Action?",
					subtitle: "Request access and our team will set you up with a live walkthrough."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 flex justify-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestAccessModal, {})
				})]
			})
		})
	] });
}
//#endregion
export { Page as component };
