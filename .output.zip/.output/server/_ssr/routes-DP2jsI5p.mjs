import { _ as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { j as CircleCheck } from "../_libs/lucide-react.mjs";
import { i as RequestAccessModal } from "./request-access-modal-YqegOqKY.mjs";
import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DP2jsI5p.js
var import_jsx_runtime = require_jsx_runtime();
var $$splitComponentImporter = () => import("./routes-DRZUOsvv.mjs");
var Route = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "Dverif — Verify Documents in Minutes" },
		{
			name: "description",
			content: "Dverif is an invite-only platform to verify documents in minutes. Stop scams, cut hassle, eliminate delays."
		},
		{
			property: "og:title",
			content: "Dverif — Verify Documents in Minutes"
		},
		{
			property: "og:description",
			content: "Invite-only document verification for modern organizations."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
function PlanCard({ name, price, period, tagline, features, featured, badge }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `card-hover relative flex h-full flex-col rounded-2xl border p-7 sm:p-8 transition-all duration-300 hover:-translate-y-1 hover:shadow-[var(--shadow-elegant)] ${featured ? "border-primary bg-card shadow-[var(--shadow-glow)]" : "border-border bg-card"}`,
		children: [
			featured && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute -top-3 left-6 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full btn-primary-glow px-3 py-1 text-xs font-semibold",
					children: "Recommended"
				}), badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full border border-primary/30 bg-card px-3 py-1 text-xs font-semibold text-primary",
					children: badge
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm font-semibold text-muted-foreground",
				children: name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap items-baseline gap-x-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-4xl font-bold",
					children: price
				}), period && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted-foreground",
					children: period
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-sm text-muted-foreground",
				children: tagline
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-7 border-t border-border pt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-3 text-sm",
					children: features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-primary shrink-0 mt-0.5" }),
							" ",
							f
						]
					}, f))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-auto pt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestAccessModal, { triggerLabel: "Subscribe A Plan" })
			})
		]
	});
}
function SectionHeader({ eyebrow, title, subtitle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl text-center",
		children: [
			eyebrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "section-kicker",
				children: eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-4 text-3xl font-bold tracking-tight sm:text-4xl",
				children: title
			}),
			subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted-foreground",
				children: subtitle
			})
		]
	});
}
//#endregion
export { Route as n, SectionHeader as r, PlanCard as t };
