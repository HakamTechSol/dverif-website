import { n as __toESM } from "../_runtime.mjs";
import { _ as require_jsx_runtime, v as require_react } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { R as ArrowRight, a as TriangleAlert, f as Quote, j as CircleCheck, k as Clock, s as Star, u as ShieldAlert } from "../_libs/lucide-react.mjs";
import { i as RequestAccessModal } from "./request-access-modal-YqegOqKY.mjs";
import { n as SiteLayout, t as ReadyToSimplify } from "./site-layout-OToWjpKs.mjs";
import { n as ProductJourney } from "./product-capabilities-Cs1FSbPz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DRZUOsvv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductJourney, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Problems, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Testimonials, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReadyToSimplify, {})
	] });
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "enterprise-dark",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-page grid items-center gap-12 pt-10 pb-16 sm:pt-14 sm:pb-20 lg:grid-cols-[.92fr_1.08fr] lg:gap-14 lg:pt-16 lg:pb-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "animate-fade-up flex w-full flex-col items-center text-center lg:items-start lg:text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-7 max-w-3xl text-5xl font-bold leading-[0.98] tracking-tight sm:text-6xl lg:text-[4.5rem]",
						children: [
							"Verify Documents",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "bg-gradient-to-r from-primary to-[color:var(--primary-glow)] bg-clip-text text-transparent",
								children: "in Minutes"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-7 max-w-2xl text-base leading-7 text-slate-300 sm:text-lg",
						children: "Scams, endless back-and-forth and long delays cost you time and reputation. Dverif brings issuers, verifiers, and organizations together in one clean workflow."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-9 flex w-full flex-col justify-center gap-3 sm:w-auto sm:flex-row lg:justify-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestAccessModal, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#how",
							className: "inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-white/15 bg-white/8 px-5 text-sm font-medium text-white transition-colors hover:bg-white/15",
							children: ["See how it works ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap justify-center gap-x-6 gap-y-3 text-sm text-slate-300 lg:justify-start",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-primary" }), " Zero Scam Tolerance"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-primary" }), " Minutes, Not Weeks"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-primary" }), " Audit Trail"]
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "animate-fade-in-soft w-full",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardMock, {})
			})]
		})
	});
}
function DashboardMock() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute -inset-8 bg-gradient-to-tr from-primary/20 to-transparent blur-3xl rounded-full",
			"aria-hidden": true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "dark-panel relative aspect-video overflow-hidden rounded-3xl",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				className: "pointer-events-none h-full w-full object-cover",
				src: "/assets/dverifvideo.mp4",
				autoPlay: true,
				muted: true,
				loop: true,
				playsInline: true,
				"aria-label": "Dverif platform overview",
				children: "Your browser does not support the video tag."
			})
		})]
	});
}
function Problems() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "enterprise-light py-12 lg:py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container-page",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "section-frame px-5 py-10 sm:px-8 lg:px-12 lg:py-14",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, { title: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block",
					children: "Verification is Broken ?"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block",
					children: "DVerif will Fix it !"
				})] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-5 md:grid-cols-3 lg:gap-7",
					children: [
						{
							icon: ShieldAlert,
							title: "Scams",
							body: "Forged documents slip through email chains. Dverif verifies at the source."
						},
						{
							icon: TriangleAlert,
							title: "Hassle",
							body: "Chasing issuers over phone and email costs your team days each week."
						},
						{
							icon: Clock,
							title: "Delays",
							body: "Waiting weeks for a verification blocks admissions, hiring and payouts."
						}
					].map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "surface-card card-hover relative overflow-hidden rounded-2xl p-6 sm:p-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-primary to-primary-glow" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(it.icon, { className: "h-5 w-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 text-lg font-semibold",
								children: it.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: it.body
							})
						]
					}, it.title))
				})]
			})
		})
	});
}
function Testimonials() {
	const testimonials = [
		{
			quote: "Dverif has turned a slow, manual verification process into a workflow our team can complete with confidence.",
			name: "Ayesha Khan",
			role: "Admissions Manager",
			initials: "AK"
		},
		{
			quote: "We now have a clear audit trail for every request and can respond to applicants far more quickly.",
			name: "Hamza Ali",
			role: "Operations Lead",
			initials: "HA"
		},
		{
			quote: "The platform makes it simple to verify documents directly at the source without the usual back-and-forth.",
			name: "Sara Ahmed",
			role: "People Operations",
			initials: "SA"
		}
	];
	const [activeIndex, setActiveIndex] = (0, import_react.useState)(0);
	const [touchStartX, setTouchStartX] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const interval = window.setInterval(() => {
			setActiveIndex((currentIndex) => (currentIndex + 1) % testimonials.length);
		}, 5e3);
		return () => window.clearInterval(interval);
	}, [testimonials.length]);
	const changeSlide = (direction) => {
		setActiveIndex((currentIndex) => (currentIndex + direction + testimonials.length) % testimonials.length);
	};
	const handleTouchEnd = (touchEndX) => {
		if (touchStartX === null) return;
		const swipeDistance = touchStartX - touchEndX;
		if (Math.abs(swipeDistance) > 50) changeSlide(swipeDistance > 0 ? 1 : -1);
		setTouchStartX(null);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "enterprise-light py-12 lg:py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container-page",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "section-frame px-5 py-10 sm:px-8 lg:px-12 lg:py-14",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
						eyebrow: "Testimonials",
						title: "Trusted By Thousands"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 overflow-hidden",
						onTouchStart: (event) => setTouchStartX(event.touches[0].clientX),
						onTouchEnd: (event) => handleTouchEnd(event.changedTouches[0].clientX),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex transition-transform duration-700 ease-in-out",
							style: { transform: `translateX(-${activeIndex * 100}%)` },
							children: testimonials.map((testimonial) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full shrink-0 px-0.5",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "surface-card mx-auto flex min-h-64 max-w-2xl flex-col rounded-2xl p-6 sm:p-7",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quote, {
												className: "h-8 w-8 text-primary/70",
												"aria-hidden": "true"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex gap-0.5 text-primary",
												"aria-label": "5 out of 5 stars",
												children: Array.from({ length: 5 }).map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
													className: "h-3.5 w-3.5 fill-current",
													"aria-hidden": "true"
												}, index))
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
											className: "mt-5 text-base leading-7 text-foreground",
											children: [
												"“",
												testimonial.quote,
												"”"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
											className: "mt-auto flex items-center gap-3 pt-6",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "grid h-10 w-10 place-items-center rounded-full bg-primary/10 text-sm font-semibold text-primary",
												children: testimonial.initials
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cite", {
												className: "not-italic text-sm font-semibold text-foreground",
												children: testimonial.name
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: testimonial.role
											})] })]
										})
									]
								})
							}, testimonial.name))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 flex items-center justify-center gap-2",
						"aria-label": "Testimonial navigation",
						children: testimonials.map((testimonial, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setActiveIndex(index),
							className: `h-2.5 rounded-full transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 ${activeIndex === index ? "w-7 bg-primary" : "w-2.5 bg-primary/25 hover:bg-primary/50"}`,
							"aria-label": `Show testimonial ${index + 1}`,
							"aria-current": activeIndex === index
						}, testimonial.name))
					})
				]
			})
		})
	});
}
function PlanCard({ name, price, period, tagline, features, featured, badge }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `card-hover relative flex h-full flex-col rounded-2xl border p-7 sm:p-8 transition-all duration-300 hover:-translate-y-1 hover:shadow-[var(--shadow-elegant)] ${featured ? "border-primary bg-card shadow-[var(--shadow-glow)]" : "border-border bg-card"}`,
		children: [
			featured && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute -top-3 left-6 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full btn-primary-glow px-3 py-1 text-xs font-semibold",
					children: "Recommended"
				}), badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full border border-primary/30 bg-card px-3 py-1 text-xs font-semibold text-primary",
					children: badge
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-sm font-semibold text-muted-foreground",
				children: name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-wrap items-baseline gap-x-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-4xl font-bold",
					children: price
				}), period && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted-foreground",
					children: period
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-sm text-muted-foreground",
				children: tagline
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-7 border-t border-border pt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "space-y-3 text-sm",
					children: features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-start gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-primary shrink-0 mt-0.5" }),
							" ",
							f
						]
					}, f))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-auto pt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestAccessModal, { triggerLabel: "Subscribe A Plan" })
			})
		]
	});
}
function SectionHeader({ eyebrow, title, subtitle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl text-center",
		children: [
			eyebrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "section-kicker",
				children: eyebrow
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-4 text-3xl font-bold tracking-tight sm:text-4xl",
				children: title
			}),
			subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted-foreground",
				children: subtitle
			})
		]
	});
}
//#endregion
export { PlanCard, SectionHeader, Home as component };
