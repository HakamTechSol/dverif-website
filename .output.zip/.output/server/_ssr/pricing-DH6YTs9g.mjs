import { _ as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { i as RequestAccessModal } from "./request-access-modal-YqegOqKY.mjs";
import { n as SiteLayout } from "./site-layout-OToWjpKs.mjs";
import { r as SectionHeader, t as PlanCard } from "./routes-DP2jsI5p.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pricing-DH6YTs9g.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "enterprise-dark py-20 sm:py-24 lg:py-28",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "container-page text-center animate-fade-up",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-4xl font-bold tracking-tight sm:text-5xl",
					children: "Simple, Honest Pricing"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-4 max-w-2xl text-lg text-slate-300",
					children: "Choose the plan that fits your verification needs. Both plans include a simple request-access process."
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "enterprise-light section-y",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "container-page",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "section-frame mx-auto grid max-w-6xl items-stretch gap-6 p-5 sm:p-8 lg:grid-cols-2 lg:gap-8 lg:p-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanCard, {
						name: "Monthly",
						price: "PKR 5,000",
						period: "/ month",
						tagline: "Flexible monthly billing",
						features: [
							"Up to 50 requests / month",
							"1 team member",
							"Email support",
							"Basic audit log"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanCard, {
						name: "Yearly",
						price: "PKR 50,000",
						period: "/ year",
						tagline: "Best value for growing teams",
						featured: true,
						badge: "Save 10%",
						features: [
							"Unlimited requests",
							"Roles & permissions",
							"Priority support",
							"Advanced audit"
						]
					})]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "enterprise-dark section-y",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-3xl px-4 text-center sm:px-6 lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, {
					title: "Not Sure Which Plan?",
					subtitle: "Schedule a meeting and our team will help you choose the right plan."
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestAccessModal, {})
			})]
		})
	] });
}
//#endregion
export { Page as component };
