import { _ as require_jsx_runtime } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { E as FileCheckCorner, F as CalendarDays, I as Building2, L as Bell, O as CreditCard, P as ChartNoAxesCombined, S as KeyRound, T as FileText, l as ShieldCheck, r as UsersRound, x as LayoutDashboard } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-capabilities-Cs1FSbPz.js
var import_jsx_runtime = require_jsx_runtime();
var journeys = [
	"Org signs up → picks a plan → invites team.",
	"Employee clocks attendance, requests leave, views payslips.",
	"Org issues a Verified Certificate → employee shares the QR/PDF.",
	"Any verifier scans the QR → instant, tamper-proof confirmation."
];
var capabilities = [
	{
		icon: KeyRound,
		title: "Authentication & Security",
		points: [
			"Email + password login with OTP (one-time-password) verification.",
			"JWT access tokens with rotating refresh tokens (blacklist on logout).",
			"Forgot / reset / set password flows with secure email links.",
			"Rate limiting, Helmet headers, CORS allow-listing, and input validation.",
			"Role-based access: Super Admin, Org Admin, Employee.",
			"Audit logging of sensitive actions and full login history tracking."
		]
	},
	{
		icon: Building2,
		title: "Organizations (Multi-Tenant)",
		points: ["Each organization is isolated with its own members, data, branding (logo), and subscription plan.", "Org Admin dashboard to manage the team, templates, and settings."]
	},
	{
		icon: UsersRound,
		title: "Employee & Team Management",
		points: ["Create and manage employee profiles with document uploads.", "Organization-scoped employee directory and org-admin controls."]
	},
	{
		icon: CalendarDays,
		title: "Attendance & Leave Management",
		points: [
			"Clock-in / clock-out and attendance tracking per employee and per org.",
			"Org-level attendance views and reporting.",
			"Request and approve leaves with balance tracking.",
			"Employee and Org-Admin leave dashboards."
		]
	},
	{
		icon: FileText,
		title: "Payroll & Salary",
		points: ["Salary records and auto-generated payslip PDFs.", "Payroll dashboard for employees and org admins."]
	},
	{
		icon: ChartNoAxesCombined,
		title: "Dashboard, Analytics & i18n",
		points: ["Charts and KPIs for attendance, leaves, verifications, and organization health.", "Built-in i18n with English and Urdu locales."]
	},
	{
		icon: FileCheckCorner,
		title: "Verification & Certificates",
		featured: true,
		points: [
			"Generate verification certificates (employment, attendance, salary) rendered as PDF with an embedded QR code.",
			"Public /verify/:qrToken page lets anyone scan & verify a certificate instantly — tamper detection included.",
			"Verification request inbox and request lifecycle (pending → verified)."
		]
	},
	{
		icon: LayoutDashboard,
		title: "Dynamic Templates & Requests",
		points: ["Org Admins build custom request templates with configurable fields.", "Employees submit requests against templates; data rendered dynamically."]
	},
	{
		icon: Bell,
		title: "Notifications",
		points: ["In-app notifications for requests, verifications, and approvals."]
	},
	{
		icon: CreditCard,
		title: "Payments & Subscriptions",
		points: ["Payment gateway integration, plans, and subscription gating (SubscriptionLocked UI when a plan expires).", "Admin payments dashboard and plan management."]
	},
	{
		icon: ShieldCheck,
		title: "Leads & Admin Console",
		points: ["Super-admin lead capture and management.", "Admin dashboards: users, organizations, payments, activity logs, unresponsive orgs, and null-request monitoring."]
	}
];
function ProductJourney() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "enterprise-light py-12 lg:py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "container-page",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-8 lg:grid-cols-[.78fr_1.22fr] lg:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "section-kicker",
					children: "One connected platform"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-3xl font-bold tracking-tight sm:text-4xl",
					children: "From your organization to instant verification."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "grid gap-3 sm:grid-cols-2",
					children: journeys.map((journey, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "surface-card flex gap-4 rounded-2xl p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid h-8 w-8 shrink-0 place-items-center rounded-full bg-primary/10 text-sm font-bold text-primary",
							children: index + 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm leading-6 text-muted-foreground",
							children: journey
						})]
					}, journey))
				})]
			})
		})
	});
}
function ProductCapabilities() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "enterprise-light section-y",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "container-page",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-3xl text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "section-kicker",
					children: "Platform capabilities"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-3xl font-bold tracking-tight sm:text-4xl",
					children: "Everything your organization needs in one place."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-5 md:grid-cols-2 xl:grid-cols-3",
				children: capabilities.map(({ icon: Icon, title, points, featured }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: `relative rounded-2xl border p-6 ${featured ? "border-primary bg-primary/5 shadow-[var(--shadow-glow)] md:col-span-2 xl:col-span-2" : "border-border bg-card shadow-sm"}`,
					children: [
						featured && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute right-5 top-5 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground",
							children: "Flagship"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-5 text-xl font-semibold tracking-tight",
							children: title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-3 text-sm leading-6 text-muted-foreground",
							children: points.map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" }), point]
							}, point))
						})
					]
				}, title))
			})]
		})
	});
}
//#endregion
export { ProductJourney as n, ProductCapabilities as t };
