import { n as __toESM } from "../_runtime.mjs";
import { _ as require_jsx_runtime, v as require_react } from "../_libs/@radix-ui/react-accordion+[...].mjs";
import { C as Instagram, D as Facebook, N as Check, R as ArrowRight, T as FileText, _ as Menu, b as Linkedin, l as ShieldCheck, m as Moon, n as X, o as Sun, t as Youtube, v as Mail } from "../_libs/lucide-react.mjs";
import { i as RequestAccessModal, l as useTheme, n as Button$1 } from "./request-access-modal-YqegOqKY.mjs";
import { g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/site-layout-OToWjpKs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var links = [
	{
		to: "/",
		label: "Home"
	},
	{
		to: "/features",
		label: "Features"
	},
	{
		to: "/pricing",
		label: "Pricing"
	},
	{
		to: "/contact",
		label: "Contact"
	}
];
function Navbar() {
	const { theme, toggle } = useTheme();
	const [open, setOpen] = (0, import_react.useState)(false);
	const path = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-50 px-3 pt-3 sm:px-5 sm:pt-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass-nav mx-auto max-w-[1280px] rounded-[18px] border border-border/80 shadow-[0_14px_36px_-22px_color-mix(in_oklab,var(--foreground)_38%,transparent)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-16 items-center justify-between gap-3 px-4 py-2 sm:px-5 lg:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						"aria-label": "Dverif home",
						className: "flex items-center transition-opacity hover:opacity-80",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: theme === "dark" ? "/assets/logo-dark.png" : "/assets/logo-light.png",
							alt: "Dverif — Document Verification Platform",
							className: "h-9 w-auto object-contain sm:h-10 animate-fade-in",
							loading: "eager",
							decoding: "async"
						}, theme)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "hidden items-center gap-1.5 md:flex",
						"aria-label": "Primary navigation",
						children: links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: l.to,
							className: `relative rounded-lg px-4 py-2 text-sm font-medium transition-all duration-400 lg:px-5 after:absolute after:inset-x-3 after:bottom-1 after:h-0.5 after:origin-left after:rounded-full after:bg-primary after:transition-transform after:duration-300 ${path === l.to ? "bg-primary/10 text-primary after:scale-x-100" : "text-muted-foreground after:scale-x-0 hover:text-foreground hover:after:scale-x-100"}`,
							children: l.label
						}, l.to))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex shrink-0 items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								"aria-label": "Toggle theme",
								onClick: toggle,
								className: "grid h-8 w-8 place-items-center rounded-lg border border-border bg-card/80 transition-all duration-300 hover:-translate-y-0.5 hover:bg-accent hover:shadow-sm",
								children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "h-4 w-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "hidden md:block",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestAccessModal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
									className: "h-10 rounded-xl px-4 shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:scale-[1.02] hover:brightness-95",
									children: "Schedule A Meeting"
								}) })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
								variant: "ghost",
								size: "icon",
								className: "h-10 w-10 rounded-xl border border-border bg-card/80 transition-all duration-300 hover:bg-accent md:hidden",
								onClick: () => setOpen((v) => !v),
								"aria-label": "Menu",
								children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
							})
						]
					})
				]
			}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1 border-t border-border/80 bg-background/85 px-4 py-3 backdrop-blur-xl md:hidden",
				children: [links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: l.to,
					onClick: () => setOpen(false),
					className: `block rounded-xl px-3 py-2.5 text-sm font-medium transition-colors duration-300 ${path === l.to ? "bg-primary/10 text-primary" : "text-foreground hover:bg-accent"}`,
					children: l.label
				}, l.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "pt-2 pb-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestAccessModal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button$1, {
						className: "h-10 w-full rounded-xl transition-all duration-300 hover:brightness-95",
						children: "Schedule A Meeting"
					}) })
				})]
			})]
		})
	});
}
var productLinks = [
	{
		label: "Features",
		to: "/features"
	},
	{
		label: "How It Works",
		to: "/",
		hash: "how"
	},
	{
		label: "Pricing",
		to: "/pricing"
	},
	{
		label: "Contact",
		to: "/contact"
	}
];
var companyLinks = [
	{
		label: "Privacy Policy",
		to: "/privacy-policy"
	},
	{
		label: "Terms & Conditions",
		to: "/terms"
	},
	{
		label: "FAQ",
		to: "/faq"
	}
];
var socialIcons = [
	{
		label: "LinkedIn",
		icon: Linkedin,
		href: "https://www.linkedin.com",
		tone: "border-[#0a66c2] bg-[#0a66c2] text-white hover:bg-[#004182]"
	},
	{
		label: "Instagram",
		icon: Instagram,
		href: "https://www.instagram.com",
		tone: "border-transparent bg-[linear-gradient(135deg,#f9ce34,#ee2a7b_48%,#6228d7)] text-white hover:brightness-95"
	},
	{
		label: "Facebook",
		icon: Facebook,
		href: "https://www.facebook.com",
		tone: "border-[#1877f2] bg-[#1877f2] text-white hover:bg-[#0c63d4]"
	},
	{
		label: "YouTube",
		icon: Youtube,
		href: "https://www.youtube.com",
		tone: "border-[#ff0000] bg-[#ff0000] text-white hover:bg-[#cc0000]"
	},
	{
		label: "TikTok",
		icon: TikTokIcon,
		href: "https://www.tiktok.com",
		tone: "border-black bg-black text-white hover:bg-[#252525]"
	}
];
function TikTokIcon({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className,
		"aria-hidden": "true",
		children: "♪"
	});
}
function FooterLink({ label, to, hash }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		hash,
		className: "footer-link text-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-[#edf6ff]",
		children: label
	});
}
function SecurityIllustration() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-auto flex h-48 w-full max-w-[255px] items-center justify-center sm:h-56",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-x-4 inset-y-2 rounded-full bg-primary/15 blur-3xl" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute h-40 w-40 rounded-full border border-primary/20" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute h-52 w-52 rounded-full border border-dashed border-primary/20" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute left-3 top-7 h-1.5 w-1.5 rounded-full bg-primary shadow-[0_0_12px_3px_rgba(79,140,255,.35)]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute bottom-10 right-4 h-1.5 w-1.5 rounded-full bg-primary-glow shadow-[0_0_12px_3px_rgba(79,140,255,.35)]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative rotate-[-7deg] rounded-2xl border border-primary/30 bg-white/90 p-3.5 shadow-[0_0_32px_rgba(79,140,255,.18)] backdrop-blur",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-24 rounded-xl border border-primary/10 bg-sky-50 p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between text-primary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-5 w-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-5 rounded-full bg-[#4f8cff]/60" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-3 block h-1.5 w-full rounded-full bg-primary/20" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 block h-1.5 w-4/5 rounded-full bg-primary/15" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 block h-1.5 w-3/5 rounded-full bg-primary/15" })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute -bottom-5 -right-5 grid h-12 w-12 rotate-[7deg] place-items-center rounded-2xl border border-primary/40 bg-[linear-gradient(135deg,#4f8cff,#60a5fa)] text-white shadow-[0_0_22px_rgba(79,140,255,.35)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-6 w-6" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute bottom-5 left-9 flex items-center gap-1.5 rounded-full border border-primary/25 bg-white/85 px-2.5 py-1 text-[10px] font-medium text-primary backdrop-blur",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3 w-3" }), " Verified"]
			})
		]
	});
}
function Footer() {
	const { theme } = useTheme();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "site-footer overflow-hidden",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 pb-7 pt-14 sm:px-6 sm:pt-16 lg:px-8 lg:pt-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-x-8 gap-y-11 md:grid-cols-2 xl:grid-cols-12 xl:gap-y-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "xl:col-span-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									"aria-label": "Dverif home",
									className: "ml-5 inline-flex transition-opacity hover:opacity-80",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: theme === "dark" ? "/assets/logo-dark.png" : "/assets/logo-light.png",
										alt: "Dverif — Document Verification Platform",
										className: "-ml-5 h-16 w-auto object-contain",
										loading: "lazy",
										decoding: "async"
									}, theme)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-5 max-w-sm text-sm leading-6 text-muted-foreground",
									children: "Verify documents in minutes. Dverif is an invite-only platform helping organizations stop scams and streamline verification."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "mailto:dverif26@gmail.com",
									className: "mt-5 inline-flex items-center gap-2 text-sm text-foreground transition-colors hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4 text-primary" }), " dverif26@gmail.com"]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "xl:col-span-2",
							"aria-label": "Product links",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold text-foreground",
								children: "Product"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 space-y-1",
								children: productLinks.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterLink, { ...link }) }, link.label))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: "xl:col-span-2",
							"aria-label": "Company links",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold text-foreground",
								children: "Company"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 space-y-1",
								children: companyLinks.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FooterLink, { ...link }) }, link.label))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
							className: "md:col-span-2 xl:col-span-4 xl:-mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecurityIllustration, {})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-11 flex flex-col items-center text-center",
					"aria-label": "Dverif social channels",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground",
						children: "Follow Us"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex max-w-sm flex-wrap justify-center gap-2",
						children: socialIcons.map(({ label, icon: Icon, href, tone }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href,
							target: "_blank",
							rel: "noreferrer",
							title: label,
							"aria-label": `Visit Dverif on ${label}`,
							className: `grid h-9 w-9 place-items-center rounded-lg border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white ${tone}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "h-4 w-4",
								"aria-hidden": "true"
							})
						}, label))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-10 flex flex-col items-center gap-4 border-t border-primary/15 pt-6 text-center text-xs text-muted-foreground sm:text-sm lg:flex-row lg:justify-between lg:text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "© 2026 Dverif. All rights reserved." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-wrap justify-center gap-x-5 gap-y-2",
						"aria-label": "Legal links",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Design and Developed by Hakam TechSol" })
					})]
				})
			]
		})
	});
}
function ReadyToSimplify() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-[#102b52] px-4 py-12 sm:px-6 lg:px-8 lg:py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-7xl",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden rounded-3xl border border-[#6fa6f5]/30 bg-[linear-gradient(115deg,#1b3b6b_0%,#24548d_48%,#1b4275_100%)] px-6 py-8 sm:px-9 sm:py-10 lg:flex lg:items-center lg:justify-between lg:gap-10 lg:px-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute -right-24 -top-32 h-72 w-72 rounded-full border border-white/15 bg-[#79b5ff]/20 blur-2xl",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute inset-0 opacity-30 [background-image:radial-gradient(rgba(255,255,255,.42)_1px,transparent_1px)] [background-size:22px_22px]",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative max-w-2xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-semibold tracking-tight text-white sm:text-3xl",
							children: "Ready to simplify document verification?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-6 text-slate-200/85 sm:text-base",
							children: "Join forward-thinking organizations that trust Dverif to verify documents faster and build more trust."
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RequestAccessModal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "relative mt-6 inline-flex h-11 w-full shrink-0 items-center justify-center gap-2 rounded-xl bg-[#4f8cff] px-5 text-sm font-semibold text-white transition-transform hover:-translate-y-0.5 hover:bg-[#3d7ce8] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-[#24548d] lg:mt-0 lg:w-auto",
						children: ["Request Access ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
					}) })
				]
			})
		})
	});
}
function SiteLayout({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen flex flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navbar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {})
		]
	});
}
//#endregion
export { SiteLayout as n, ReadyToSimplify as t };
