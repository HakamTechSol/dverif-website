globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"1ad5a-Lyn8jc6hiExbt4/oN8sO7ItmWCA\"",
		"mtime": "2026-07-31T15:11:01.914Z",
		"size": 109914,
		"path": "../public/favicon.ico"
	},
	"/assets/building-2-BY3gl2Rc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"174-cWhrUPI/YIiFE9dAMtamykISDxM\"",
		"mtime": "2026-09-01T20:00:31.009Z",
		"size": 372,
		"path": "../public/assets/building-2-BY3gl2Rc.js"
	},
	"/assets/contact-BCTecddh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a62-CStjSgOotgf3uCREoFU03Mbqz5s\"",
		"mtime": "2026-09-01T20:00:31.009Z",
		"size": 6754,
		"path": "../public/assets/contact-BCTecddh.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"ae-hLVBrSrDdpIw3Xl0dJPRkupPepQ\"",
		"mtime": "2026-07-29T11:14:07.982Z",
		"size": 174,
		"path": "../public/robots.txt"
	},
	"/assets/attendence.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1541b-DwA3/Q6REQJoWNmAh6dgxXuWi3U\"",
		"mtime": "2026-09-01T18:54:13.533Z",
		"size": 87067,
		"path": "../public/assets/attendence.jpeg"
	},
	"/assets/faq-DWTCtDgr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3d4c-t8v57h5vcCwEugI5aeeI9A3MmZI\"",
		"mtime": "2026-09-01T20:00:31.009Z",
		"size": 15692,
		"path": "../public/assets/faq-DWTCtDgr.js"
	},
	"/assets/documentreviwe.jpeg": {
		"type": "image/jpeg",
		"etag": "\"107ee-D9MyEvwT4meS6mHJIbUMNUpUuVw\"",
		"mtime": "2026-09-01T19:04:08.858Z",
		"size": 67566,
		"path": "../public/assets/documentreviwe.jpeg"
	},
	"/assets/features-DaE0NMQS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18d3-tLKDnzkNeW87wXtWJBOne+/0VqU\"",
		"mtime": "2026-09-01T20:00:31.010Z",
		"size": 6355,
		"path": "../public/assets/features-DaE0NMQS.js"
	},
	"/assets/index-C-J9K1Vf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"694bd-fpMy6puZOj9j0GuOKEi6CaGxqG0\"",
		"mtime": "2026-09-01T20:00:31.005Z",
		"size": 431293,
		"path": "../public/assets/index-C-J9K1Vf.js"
	},
	"/assets/inbox.jpeg": {
		"type": "image/jpeg",
		"etag": "\"10ba1-jwmjuDgaDqi5UmZHoZgApOXVr/U\"",
		"mtime": "2026-09-01T18:51:44.946Z",
		"size": 68513,
		"path": "../public/assets/inbox.jpeg"
	},
	"/assets/langugesupport.jpeg": {
		"type": "image/jpeg",
		"etag": "\"f43a-xJOPDvGIB5fZv+IJDBKkWGIPI44\"",
		"mtime": "2026-09-01T18:54:45.883Z",
		"size": 62522,
		"path": "../public/assets/langugesupport.jpeg"
	},
	"/assets/leaverequest1.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1328c-nE3Ijvcb0w8pWhF39nHffnHuI18\"",
		"mtime": "2026-09-01T18:53:33.834Z",
		"size": 78476,
		"path": "../public/assets/leaverequest1.jpeg"
	},
	"/assets/leaverequest2.jpeg": {
		"type": "image/jpeg",
		"etag": "\"153e7-TnMzANQ3gHCVolfhrqOU326jvbw\"",
		"mtime": "2026-09-01T18:53:59.909Z",
		"size": 87015,
		"path": "../public/assets/leaverequest2.jpeg"
	},
	"/assets/login.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1816c-MNZOAw8bhzXcS8ay4GD7iIuQEKs\"",
		"mtime": "2026-09-01T18:49:54.454Z",
		"size": 98668,
		"path": "../public/assets/login.jpeg"
	},
	"/assets/logo-dark.png": {
		"type": "image/png",
		"etag": "\"1e300-fJ3tTCDOPI8IKi0inPC+k6G4eMo\"",
		"mtime": "2026-07-31T11:02:52.031Z",
		"size": 123648,
		"path": "../public/assets/logo-dark.png"
	},
	"/assets/logo-light.png": {
		"type": "image/png",
		"etag": "\"20bfa-my62ddibGwFuixRCabCFzp0Eer8\"",
		"mtime": "2026-07-31T11:02:33.732Z",
		"size": 134138,
		"path": "../public/assets/logo-light.png"
	},
	"/assets/pricing-DE_Y-cIu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6a3-3wHrbFtcX0vlGQ6yThyMtj4XdIE\"",
		"mtime": "2026-09-01T20:00:31.019Z",
		"size": 1699,
		"path": "../public/assets/pricing-DE_Y-cIu.js"
	},
	"/assets/multiadmin.jpeg": {
		"type": "image/jpeg",
		"etag": "\"12a63-ltGBMTceVCr4KzXJ6/nbTGPBuNc\"",
		"mtime": "2026-09-01T18:53:18.955Z",
		"size": 76387,
		"path": "../public/assets/multiadmin.jpeg"
	},
	"/assets/privacy-policy-B5jyyCNk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"257-95NW9ayP7zkfHCpwV7UIWt+KNN4\"",
		"mtime": "2026-09-01T20:00:31.020Z",
		"size": 599,
		"path": "../public/assets/privacy-policy-B5jyyCNk.js"
	},
	"/assets/product-capabilities-B0NeP2S_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1bef-+HT+x06zidusKEbcTJo1V7vAfZo\"",
		"mtime": "2026-09-01T20:00:31.020Z",
		"size": 7151,
		"path": "../public/assets/product-capabilities-B0NeP2S_.js"
	},
	"/assets/routes-DxYCuCII.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"28cd-u0fnD611uF+Ef+7dUdaSoZBJTTE\"",
		"mtime": "2026-09-01T20:00:31.020Z",
		"size": 10445,
		"path": "../public/assets/routes-DxYCuCII.js"
	},
	"/assets/site-layout-uubH6fwi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34d1-mJW5G7LnNbaygrcIk587grTekhM\"",
		"mtime": "2026-09-01T20:00:31.020Z",
		"size": 13521,
		"path": "../public/assets/site-layout-uubH6fwi.js"
	},
	"/assets/salarymanagment.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1276d-xfqYmeKKhVuB9cUaEa2Y+HA9D8I\"",
		"mtime": "2026-09-01T18:54:27.696Z",
		"size": 75629,
		"path": "../public/assets/salarymanagment.jpeg"
	},
	"/assets/styles-DFrQNInJ.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1bc3d-TTHJLkJr5cw8Mg14sC7A1PVzgNc\"",
		"mtime": "2026-09-01T20:00:31.020Z",
		"size": 113725,
		"path": "../public/assets/styles-DFrQNInJ.css"
	},
	"/assets/dverifvideo.mp4": {
		"type": "video/mp4",
		"etag": "\"182574-wYu4UE5xBUwbS57qf8f+aT4j/eE\"",
		"mtime": "2026-08-31T15:55:38.672Z",
		"size": 1582452,
		"path": "../public/assets/dverifvideo.mp4"
	},
	"/assets/teampage.jpeg": {
		"type": "image/jpeg",
		"etag": "\"10f06-n7zqtP4UZZKCatA+0NqiiUJOW0I\"",
		"mtime": "2026-09-01T18:52:37.192Z",
		"size": 69382,
		"path": "../public/assets/teampage.jpeg"
	},
	"/assets/terms-Dj65idUv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24e-JTnQbdMRqxKvj1D8BOQnSG0WwOo\"",
		"mtime": "2026-09-01T20:00:31.020Z",
		"size": 590,
		"path": "../public/assets/terms-Dj65idUv.js"
	},
	"/assets/verification-request.jpeg": {
		"type": "image/jpeg",
		"etag": "\"1468a-R2nFS7CtOvoCzysxI9cxVzspfNc\"",
		"mtime": "2026-09-01T18:51:32.444Z",
		"size": 83594,
		"path": "../public/assets/verification-request.jpeg"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_prxOSV = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_prxOSV
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
