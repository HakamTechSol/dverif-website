//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C_8BdqGi.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/Dverif/dvarif-shine/src/routes/__root.tsx",
		children: [
			"/",
			"/contact",
			"/faq",
			"/features",
			"/pricing",
			"/privacy-policy",
			"/terms"
		],
		preloads: ["/assets/index-C-J9K1Vf.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C-J9K1Vf.js"
		} }]
	},
	"/": {
		filePath: "D:/Dverif/dvarif-shine/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DxYCuCII.js",
			"/assets/site-layout-uubH6fwi.js",
			"/assets/product-capabilities-B0NeP2S_.js"
		]
	},
	"/contact": {
		filePath: "D:/Dverif/dvarif-shine/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-BCTecddh.js",
			"/assets/site-layout-uubH6fwi.js",
			"/assets/building-2-BY3gl2Rc.js"
		]
	},
	"/faq": {
		filePath: "D:/Dverif/dvarif-shine/src/routes/faq.tsx",
		children: void 0,
		preloads: ["/assets/faq-DWTCtDgr.js", "/assets/site-layout-uubH6fwi.js"]
	},
	"/features": {
		filePath: "D:/Dverif/dvarif-shine/src/routes/features.tsx",
		children: void 0,
		preloads: [
			"/assets/features-DaE0NMQS.js",
			"/assets/site-layout-uubH6fwi.js",
			"/assets/product-capabilities-B0NeP2S_.js"
		]
	},
	"/pricing": {
		filePath: "D:/Dverif/dvarif-shine/src/routes/pricing.tsx",
		children: void 0,
		preloads: ["/assets/pricing-DE_Y-cIu.js", "/assets/site-layout-uubH6fwi.js"]
	},
	"/privacy-policy": {
		filePath: "D:/Dverif/dvarif-shine/src/routes/privacy-policy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-policy-B5jyyCNk.js", "/assets/site-layout-uubH6fwi.js"]
	},
	"/terms": {
		filePath: "D:/Dverif/dvarif-shine/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-Dj65idUv.js", "/assets/site-layout-uubH6fwi.js"]
	}
} });
//#endregion
export { tsrStartManifest };
